#include <iostream>
using namespace std;
int main()
{
	//muskan from section E is making this program
	//this program will check wether two given integers are equal or not 
	cout<<"\t\t\t\t\tCHECKING WETHER NUMBER ARE EQUAL OR NOT\n\n";
	//decleration of variables
	int num1,num2;
	
	//asking for output 
	cout<<"\t\t\tEnter the first integer:\t\t";
	cin>>num1;
	
	cout<<"\t\t\tEnter the second integer:\t\t";
	cin>>num2;
	//using if and else
	if (num1==num2)
		cout<<"\n\t\t\tThe two integers are equal";

	else
		cout<<"\n\t\t\tThe two integers are not equal\n";

	system("PAUSE");
	return 0;			
}

