#include<iostream>
#include<string>
using namespace std;

int main()
{
    //muskan from secction E is making this program 
    //this program will ask the user his percentage and will show his grade as output
    cout<<"\t\t\t\tGRADE CALCULATOR\n\n";
    //decleratio of variables
    int percentage;
    cout<<"\t\t\t*Enter your percentage:\t\t";
    cin>>percentage;
    
    //if and else if condtion
    if (percentage>=90)
    	cout<<"\n\t\t*A1*\n";
    	
    else if ( percentage>=80 && percentage<=89)
    	cout<<"\n\n\t\t\t*A*\n";
    
	else if ( percentage>=70 && percentage<=79)
		cout<<"\n\n\t\t\t*B*\n";
	
	else if ( percentage>=60 && percentage<=69)
		cout<<"\n\n\t\t\t*C*\n";
		
	else 
		cout<<"\n\n\t\t\t*F*\n";
		
	system ("PAUSE");
    return 0;
    
	}
