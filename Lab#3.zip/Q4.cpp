#include<iostream>
using namespace std;
int main()

{
	/*muskan vaswanui is making this programming. It is about 
	checking wether your number is even or odd.*/
	
	cout<<"\t\t\t\t\tCHECKING WETHER YOUR NUMBER IS EVEN OR ODD\n\n";
	//decleration of variables
	int a;

	cout<<"\t\t\tEnter your number:\t";
	cin>>a;
	//IF AND
	if (a%2==0)
	cout<<"\t\t\t number  "<<a<<"  is an even number"<<endl;
	else if (a%2==1)
	cout<<"\t\t\t number  "<<a<<"  is an odd number"<<endl;
	
	system("PAUSE");
	return 0;
	}
