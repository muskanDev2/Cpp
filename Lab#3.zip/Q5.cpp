 #include <iostream>
using namespace std;
int main()
{
	/*muskan from section E is writng this program
	The program is about checking wether an number is +ve,-ve,or 0*/	
	cout<<"\n\t\t\t\tCHECK THE number FOR positive, negative, OR zero\n";
	
	//decleration of variable 
	int a;
	
	//taking input 
	cout<<"\n\t\t\tEnter the number:\t\t";
	cin>>a;
	
	//using if else condition
	if (a<0)
	cout<<"\n\t\t\t"<<a<<" is NEGATIVE NUMBER\n\n";

	else if (a>0)
	cout<<"\n\t\t\t"<<a<<" is POSITIVE NUMBER\n\n";

	else if (a==0)
	cout<<"\n\t\t\t"<<a<<" is ZERO NUMBER\n\n";

	system("PAUSE");
	return 0;

}
