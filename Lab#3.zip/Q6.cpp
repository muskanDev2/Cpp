
#include <iostream>
#include <string>
using namespace std;
int main()
{
		//muskan is writing this program
		//this program will show month name as output for month number input
		//decleration of variable 
	int month;
	cout<<"\n\t\t\tEnter a number from 1-12:\ts";
	cin>>month;
		if (month ==1)
    		cout<<"\t\t\t\tJanuary";
		else if (month==2)
    		cout<< "\t\t\t\tFebruary";
		else if (month==3)
    		cout<<"\t\t\t\tMarch";
		else if (month==4)
    		cout<<"\t\t\t\tApril";
		else if (month==5)
    		cout<<"\t\t\t\tMay";
		else if (month==6)
    		cout<<"\t\t\t\tJune";
		else if (month==7)
    		cout<<"\t\t\t\tJuly";
		else if (month==8)
    		cout<<"\t\t\t\tAugust";
		else if (month==9)
    		cout<<"\t\t\t\tSeptember";
		else if (month==10)
    		cout<<"\t\t\t\tOctober";
		else if (month==11)   			
		 cout<<"\t\t\t\tNovember";
		else if (month==12)
    		cout<<"\t\t\t\tDecember";
		else 	
    		cout<<"\t\t\t\tSorry I need a number from 1-12."<<endl;          
	return 0;
}
