#include<iostream>
using namespace std;
int main()
{
	
/*muskan from section E is making this program
through this program we will find wether the two numbers are equal, greater or less*/
int a,b;
cout<<"\t\t\t\t CHECKING WETHER THE GIVEN NUMBERS ARE EQUAL,GREATER, or LESS\n\n";

	cout<<"\t\tEnter first number:\t";
	cin>>a;
	
	cout<<"\t\tEnter second number:\t";
	cin>>b;
	

		if (a>b)
	{
		cout<<a<<"  is greater than  "<<b;
	}
		
		else if (a<b)
	{
		cout <<a<< "  is less than  "<<b;
	}
	
		else if (a=b)
	{
		cout <<a<<"  Your numbers are equal  "<<b;
	}
	system("PAUSE");
	return 0;
		}
