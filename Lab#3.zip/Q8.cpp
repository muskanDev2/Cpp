#include<iostream>
using namespace std;
int main()

{
	// this is made by muskan from section E 
	
	//decleration of variable
	int num1,num2,num3;
	//asking for output and saving the input
	
	cout<<"\n Enter First Number: ";
	cin>>num1;
	
	cout<<"\n Enter Second Number: ";
	cin>>num2;
	
	cout<<"\n Enter Third Number: ";
	cin>>num3;
	//using if and else 
	if (num1>num2 && num1>num3)
	cout<<"\n The first number is Greatest. ";
	
	else if ((num2>num1) && (num2>num3))
	cout<<"\n The second number is Greatest. ";
	
	else if ((num3>num2) && (num3>num1))
	cout<<"\n The third number is Greatest. ";
	
	system("PAUSE");	
	return 0;
	
	}

