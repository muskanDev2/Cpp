#include<iostream>

using namespace std;

int main()
{
	char student_id_card;
	cout<<"Do you have your id card?(Y/N) ";
	cin>>student_id_card;
	if (student_id_card =='Y' || student_id_card =='y')
	{
		string department;
		cout<<"whats your department? ";
		cin>>department;
	
			if (department == "EE" || department =="ee")
				cout<<"Go To Block 3";
	
				else if (department =="CS" || department== "cs")
				cout<<"Go to Block 1";
	
			else if (department =="BBA" || department== "bba")
				cout<<"Go to Block 2";
	
			else if (department =="EDU" || department== "edu")
				cout<<"Go to Knowledge center";
	}
	else {
	
	if (student_id_card =='N' || student_id_card == 'n')
	cout<<"You are not allowed to enter";
	
	else
	cout<<"invalid input";
	
	return 0;
}
	
	
	
	
}
