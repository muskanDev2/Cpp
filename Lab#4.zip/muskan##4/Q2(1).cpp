#include<iostream>
using namespace std;
int main()
{
	
	int num;

	int num2;

	char operation;

	cout<<"Enter number first number: ";
	cin>>num;
	cout<<"Enter number second number: ";
	cin>>num2;
	cout<<"Enter the operation You want to perform(+, -, *, /): ";
	cin>>operation;
	switch (operation)
	{
		case '+':
			cout<<"value is "<<num+num2;
			break;
		case '-':
			cout<<"value is "<<num-num2;
			break;
		case '*':
			cout<<"value is "<<num*num2;
			break;
		case '/':
			cout<<"value is "<<num/num2;
			break;
			
		default:
			cout<<"Invalid Input";
	}
	return 0;
			
}
