#include<iostream>

using namespace std;

int main()
{
	int month;
	
	cout<<"Enter any number between 1 to 12 to check month season: ";
	cin>>month;

	switch (month)
	{
		case 1:
			cout<<"Season is  Winter. ";
			break;
	
		case 2:
			cout<<"Season is  Winter. ";
			break;
	
		case 12:
			cout<<"Season is  Winter. ";
			break;
	
		case 3:
			cout<<"Season is  Spring. ";
			break;
	
		case 4:
			cout<<"Season is  Spring. ";
			break;
	
		case 5:
			cout<<"Season is  Summer. ";
			break;
	
		case 6:
			cout<<"Season is  Summer. ";
			break;
	
		case 7:
			cout<<"Season is  Summer. ";
			break;
	
		case 8:
			cout<<"Season is  Summer. ";
			break;
	
		case 9:
			cout<<"Season is  Summer. ";
			break;
	
		case 10:
			cout<<"Season is Autumn. ";
			break;
	
		case 11:
			cout<<"Season is Autumn. ";
			break;
	
		default:
			cout<<"Invalid Input. ";
		
	}
	
	return 0;
	
}
