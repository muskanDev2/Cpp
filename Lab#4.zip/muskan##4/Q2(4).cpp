#include<iostream>

using namespace std;

int main()
{
	char alpha;
	cout<<"Enter a alphabate : ";
	cin>>alpha;

	switch (alpha)
	{
		case 'a':
			cout<<alpha <<" is a vowel. ";
			break;
			
		case 'e':
			cout<<alpha <<" is a vowel. ";
			break;
		
		case 'i':
			cout<<alpha <<" is a vowel. ";
			break;
		
		case 'o':
			cout<<alpha <<" is a vowel. ";
			break;
		
		case 'u':
			cout<<alpha <<" is a vowel. ";
			break;
		case 'A':
			cout<<alpha <<" is a vowel. ";
			break;
		case 'E':
			cout<<alpha <<" is a vowel. ";
			break;
		case 'I':
			cout<<alpha <<" is a vowel.";
			break;
		case 'O':
			cout<<alpha <<" is a vowel. ";
			break;
		case 'U':
			cout<<alpha <<" is a vowel.";
			break;
		case 'b':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'B':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'C':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'c':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'd':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'D':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'f':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'F':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'g':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'G':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'h':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'H':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'j':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'J':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'k':
			cout<<alpha <<" is a Consonant.";
			break;	
		case 'K':
			cout<<alpha <<" is a Consonant.";
			break;	
		case 'l':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'L':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'M':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'm':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'N':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'n':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'p':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'P':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'q':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'Q':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'r':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'R':
			cout<<alpha <<" is a Consonant.";
			break;
		case 's':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'S':
			cout<<alpha <<" is a Consonant.";
			break;
		case 't':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'T':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'v':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'V':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'w':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'W':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'y':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'Y':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'x':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'X':
			cout<<alpha <<" is a Consonant.";
			break;		
		case 'z':
			cout<<alpha <<" is a Consonant.";
			break;
		case 'Z':
			cout<<alpha <<" is a Consonant.";
			break;															
		default:
			cout<<"Invalid Input!";
	}
	
	return 0;
	
}
