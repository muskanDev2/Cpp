#include<iostream>

using namespace std;

int main()
{
	int number;
	
	cout<<"Enter a number: ";
	cin>>number;
	
	int rem = (number % 10);
	
	switch (rem)
	{
		case 0:
			cout<<"Number is Even.";
			break;
		case 2:
			cout<<"Number is Even.";
			break;
		case 4:
			cout<<"Number is Even.";
			break;
		case 6:
			cout<<"Number is Even.";
			break;
		case 8:
			cout<<"Number is Even.";
			break;
		case 1:
			cout<<"Number is Odd.";
			break;
		case 3:
			cout<<"Number is Odd.";
			break;
		case 5:
			cout<<"Number is Odd.";
			break;
		case 7:
			cout<<"Number is Odd.";
			break;
		case 9:
			cout<<"Number is Odd.";
			break;								
		default:
			cout<<"Invalid Input. ";	
		
	}
	return 0;
}
