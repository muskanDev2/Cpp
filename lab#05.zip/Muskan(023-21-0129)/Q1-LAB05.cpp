#include<iostream>
using namespace std;
int main ()
{
	int num, num1;
	
	cout<<"Enter any number to print its tables:\t";
	cin>>num;
	
	for(num1=1; num1<=10; num1++)
	{
		int product=num *num1;

		cout<<num<<"x"<<num1<<"="<<product;
		cout<<endl;
	}

return 0;	
}
