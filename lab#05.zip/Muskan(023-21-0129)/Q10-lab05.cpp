
/*Modify your program in previous part so that the program will display consonants
only, no vowels.*/


#include<iostream>
using namespace std;
int main()
{
	char alpha;
	for(alpha='Z'; alpha>='A' ; alpha--)
	{
		if(((alpha!='A')&&(alpha!='E')&&(alpha!='I')&&(alpha!='O')&&(alpha!='U')))
		cout<<" "<<alpha;
		
	}


 
}
