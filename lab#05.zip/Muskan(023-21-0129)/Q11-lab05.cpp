/* Write a C++ program that receives the total number of integers (N) from the user. Then,
the program will ask the user for N real numbers. By applying for loop, your program
should find and display the largest and the lowest of the numbers. Give a proper message
for invalid user input, as shown below:
#Sample Program Run#1
How many numbers do you have? > -3
Sorry, you have entered an invalid input.
Thank You.
#Sample Program Run#2
How many numbers do you have? > 0
Opps, you don't have any number for me to process.
Thank You.
#Sample Program Run#3
How many numbers do you have? > 5
Please enter a number_1 --> 12.5
Please enter a number_2 --> -3.2
Please enter a number_3 --> 0
Please enter a number_4 --> 5
Please enter a number_5 --> 8.5
The lowest number is -3.20
The highest number is 12.50
Thank You.*/




#include<iostream>
using namespace std;
int main()
{  
   int i = 100;
   int num;
   do{
   	
   	  cout<<"Guess the number . Enter number : ";cin>>num;
   	  if(num>100)
   	  cout<<"\nNumber is greater ";
   	  else if (num<100)
   	  cout<<"\n Number is smaller  ";
   } 
   while(num!=100);
   cout<<"\nCongratulations";
	
  return 0;	
}
