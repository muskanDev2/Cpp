#include<iostream>
using namespace std;
int main()
{
	int n=68, num;

	do{
		
		cout<<"\nGuess the number:enter your number:"<<endl;
		cin>>num;
	
		if (num>68)
		{
			cout<<"\nyour number is greater than guessed one:"<<endl;
			
		}
		else if (num<68)
		cout<<"\nyour number is less than guessed one:"<<endl;
		
	}
	
while (num!=68);
	cout<<"Congragulations!";
		
	
	return 0;
}
