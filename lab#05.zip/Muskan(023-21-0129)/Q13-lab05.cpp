#include<iostream>
using namespace std;
int main()
{
 int guess=50,n;

 cout<<"Guess the number.Enter the guess: ";
 cin>>n;

 for(int i=1;i<=4 && n!=guess;i++)
 	{
 		if(n==guess)
 		cout<<"Congrats! You guessed it. "<<endl;
	 	else if (n<=guess)
 		cout<<"Your guessed number is less than actual number."<<endl;
 	
 		else
 		cout<<"Your guessed number is greater than actual number."<<endl;
 	
 		cout<<"Guess the number.Enter the guess: ";
 		cin>>n;
	}
	
 	if(n!=guess)
 		cout<<"Sorry!You have run out of atempts. The number was "<<guess;
	
	if(n==guess)
 		cout<<"Congrats! You guessed it. "<<endl;


return 0;
}
