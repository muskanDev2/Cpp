/*Write a C++ program that asks a user to input the range (final value) up to which the loop
should run and then for each number in that range, it should tell whether that (each)
number is Odd or Even. For example, if the user enters 7 as the final value of range, then it
should display like follows:*/
#include <iostream>
using namespace std;
int main()
{
	int num, num1=1;
	
	cout<<"Enter the range upto which the loop should run: ";
	cin>>num;
	
	while (num1<=num)
	{ 
	
	{
				if (num1%2==0)
			{
				cout<<num1<<" is even";
				cout<<endl;
			}
		
		
				else if(num1%2==1)
			{
				cout<<num1<<" is odd";
				cout<<endl;	
			}
		
		num1++;
	}
}
}
