#include <iostream>
using namespace std;
int main ()
{
	int range, num=1;
	
	cout<<"Enter the range upto which the loop should run:\t";
	cin>>range;
	
	do
	{
		if(num%2==0)
		{ 
			cout<<num<<endl;
		}
		num++;
	}
	while (num<=range);
	
	return 0;
}
