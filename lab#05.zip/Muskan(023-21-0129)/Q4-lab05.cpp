#include <iostream>
using namespace std;
int main ()
{
	int num=1, num2=2;
	
	for(int i; i<=55; num2++)
	{
		i=num+num2;
		cout<<i<<" ";
		num++;
	
		
	}
	 
	 
	 

	
	return 0;
}
