	 
   
   /*5. Create two separate programs (one using a 
        for loop and the other using a while loop) to
	    print a series of 10 numbers as shown below
		1 3 6 10 15 21 28 36 45 55 */

#include<iostream>
using namespace std;
int main(){
    
  	    
   int sum = 0 ;
   int i;
   cout<<" \n Print series of the numbers in for loop . \n";
   cout<<endl;
   for(i=1 ; i<=10 ; i++)
   {
   	  sum = sum+i;
   	  cout<<" "<<sum;
   }
    cout<<endl;
   cout<<"\n First Progran End\n";
  
   
   cout<<"\n Print series of numbers in  while loop . \n";
   cout<<endl;
   
   int j = 1;
   int result =0;
   
   while(j<=10)
   {	
   	result += j ;
   	cout<<" "<<result;
   	j++;
   }
   return 0;
}
