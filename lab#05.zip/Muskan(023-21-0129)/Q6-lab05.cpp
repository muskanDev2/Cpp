`	
   
   /*6. Write a C++ program that should continuously ask the user to 
        input any integer number until and unless a negative 
        number is entered. When a negative number is entered, then 
        the program should end and print the sum of all the entered numbers.
        However, it should also check that large numbers (greater than 30)
        should not be considered for calculating the sum, like shown below:*/

#include<iostream>
using namespace std;
int main()
{
	
    
  int sum = 0 , n;    
  
   
  do{
  	cout<<"Enter any number : " ; 
  	cin>>n;
  	cout<<endl;
  	if(n>30)
	cout<<"This number not be calculated " <<endl;
	if(n>0 && n<=30 )
    sum += n;
    n++;
   }
   while(n > 0 );
 
   cout<<"The sum is "<<sum;
   cout<<endl;
   return 0;
}
