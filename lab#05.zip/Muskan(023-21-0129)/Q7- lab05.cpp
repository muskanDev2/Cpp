/*the program is made by muskan from section E

The Fibonacci sequence is a series where the next term is the sum of the previous two terms. 
The first two terms of the Fibonacci sequence are 0 and 1. The series is as follows: 
0, 1, 1, 2, 3, 5, 8, 13, 21, 34, � 
Write a C++ program (using loop) to print the 10 numbers of the Fibonacci series as shown above*/ 



#include <iostream>
using namespace std;
int main()
{
	int number=0, n=1,n1, nextterm;
	cout<<number<<", ";
	 cout<<n<<",";
	 n1=number+n;
	 cout<<n1<<", ";
	 for(int i=1; i<=10;i++)
	{
		nextterm=n+n1;
		cout<<nextterm<<", ";
		n=n1;
		n1=nextterm;
		 }	 
	
	
}
