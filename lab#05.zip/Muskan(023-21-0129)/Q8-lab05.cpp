#include<iostream>
using namespace std;
int main()
{
	int books = 0, tshirt = 0, shoes = 0, num, quantity;
	
	
	cout<<"1. Books(per item price = 500)"<<endl;
	cout<<"2. T-shirt(per item price = 700)"<<endl;
	cout<<"3. Shoes(per item price = 1000)"<<endl;
	cout<<"0. to exit program "<<endl;
	cout<<"Enter any number to select any product to buy or 0 to exit: ";
	cin>>num;
	do{
	
	if(num==1)
	{
		cout<<"You have selected books.Enter Quantity: ";
		cin>>quantity;
		cout<<endl;
		books=books+(500*quantity);
	}
	
	else if(num==2)
	{
		cout<<"You have selected tshirt.Enter Quantity: ";
		cin>>quantity;
		cout<<endl;
		tshirt=tshirt+(700*quantity);
	}
	
	else if(num==3)
	{
		cout<<"You have selected shoes.Enter Quantity: ";
		cin>>quantity;
		cout<<endl;
		shoes=shoes+(1000*quantity);
	}
	
	cout<<"1. Books(per item price = 500)";
	cout<<endl;
	cout<<"2. T-shirt(per item price = 700)";
	cout<<endl;
	cout<<"3. Shoes(per item price = 1000)";
	cout<<endl;
	cout<<"0. to exit program ";
	cout<<endl;
	cout<<"Enter any number to select any product to buy or 0 to exit: ";
	cin>>num;
	}
	
	while(num!=0);

	cout<<"You have bought "<<books/500<<" Books.(Price= "<<books<<")";
	cout<<endl;
	cout<<"You have bought "<<tshirt/700<<" T-shirts.(Price= "<<tshirt<<")";
	cout<<endl;
	cout<<"You have bought "<<shoes/1000<<" Books.(Price= "<<shoes<<")";
	cout<<endl;
	cout<<"total: "<<books+tshirt+shoes;
	cout<<endl;


	return 0;

	}
