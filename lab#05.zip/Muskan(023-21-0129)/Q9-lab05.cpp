
	/*9. Using loops, write a C++ program that
    displays a series of alphabets in descending
    order from �Z� to �A.�*/



#include<iostream>
using namespace std;
int main()
{

   char alpha;
   for(alpha = 'Z' ; alpha>='A'; alpha--)
   {
   	  cout<<" "<<alpha;
   	
   }
   

 
   return 0;
}
